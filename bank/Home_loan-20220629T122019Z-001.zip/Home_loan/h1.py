x = 'python'
y = 'java'